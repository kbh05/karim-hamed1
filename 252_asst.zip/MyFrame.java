
public class MyFrame {

}
