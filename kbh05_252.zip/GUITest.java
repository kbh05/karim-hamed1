public class GUITest{
 
	@SuppressWarnings("unused")
	public static void main(String args[]){
		MyFrame frame = new MyFrame("My First GUI");
	}
 
}